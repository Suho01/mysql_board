import Image from 'next/image'
import Post from './components/post'

export default function Home() {
    return (
        <Post />
    )
}